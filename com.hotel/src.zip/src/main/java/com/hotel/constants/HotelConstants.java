package com.hotel.constants;

public class HotelConstants {
	public static final String SOMETHING_WENT_WRONG = "Something went Wrong.";
	public static final String INVALID_DATA = "Invalid Data.";
	public static final String UNAUTHORIZED_ACCESS = "Unauthorized Access.";
	public static final String STORE_LOCATION = "/home/nand/Documents/Project/HotelApp/hotelBackend/Files/";

}
